#ifndef FUNCTIONS_H
#define FUNCTIONS_H
#define nat unsigned long long int

char* get(char* message);
int ln_printf(const char *format, ...);
char *input(const char *prompt);
int intify(const char *context);
char* strrepeat(const char* str, int times);

#endif
