#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <string.h>

#include "functions.h"

// Modified get function to dynamically allocate memory for the input string
char* get(char* message) {
    char *context = malloc(256); // Allocate memory for the string
    if (context == NULL) {
        perror("Unable to allocate memory");
        exit(EXIT_FAILURE);
    }

    printf("%s", message);
    if (scanf("%255s", context) != 1) {  // Limit the input to avoid buffer overflow
        free(context);  // Free the allocated memory in case of error
        return NULL;
    }

    return context;  // Return the allocated memory
}

int last_char_is_newline() {
    int ch;
    FILE *file = fopen("console.log", "r");  // Opening a file to read the console output
    if (!file) return 1;  // Default to newline if unable to read

    fseek(file, -1, SEEK_END);  // Move to the last character in the file
    ch = fgetc(file);
    fclose(file);
    return (ch == '\n');
}

int ln_printf(const char *format, ...) {
    va_list args;
    va_start(args, format);

    // Check if the last character in the console is not a newline
    if (!last_char_is_newline()) {
        printf("\n");
    }

    // Print the formatted string
    int count = vprintf(format, args);

    // Print the trailing newline
    printf("\n");

    va_end(args);

    // Return the number of characters printed
    return count + 1;  // Plus one for the added newline
}

char *input(const char *prompt) {
    // Print the prompt
    if (prompt != NULL) {
        printf("%s", prompt);
        fflush(stdout); // Flush stdout to ensure prompt is displayed
    }

    // Allocate memory for input
    char *buffer = malloc(1000); // Adjust size as needed
    if (buffer == NULL) {
        fprintf(stderr, "Memory allocation failed\n");
        exit(1); // Exit if memory allocation fails
    }

    // Read input from stdin
    if (fgets(buffer, 1000, stdin) == NULL) {
        free(buffer); // Free allocated memory on failure
        return NULL; // Return NULL on error
    }

    // Remove newline character if present
    size_t len = strlen(buffer);
    if (len > 0 && buffer[len - 1] == '\n') {
        buffer[len - 1] = '\0';
    }

    return buffer; // Return the input string
}

int intify(const char *context){
    return atoi(context);
}
char* strrepeat(const char* str, int times) {
    if (times <= 0) {
        return strdup(""); // Return an empty string if times is zero or negative
    }

    size_t len = strlen(str);
    char* result = malloc(len * times + 1);
    if (!result) {
        fprintf(stderr, "Memory allocation failed\n");
        exit(1);
    }

    result[0] = '\0'; // Initialize the result string

    for (int i = 0; i < times; i++) {
        strcat(result, str);
    }

    return result;
}