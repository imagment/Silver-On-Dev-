#include <stdio.h>
#include <iostream>
#include <cstdlib>
#include <limits.h>
#include <string.h>
using namespace std;
int main() {
string  x="aaa";

printf("%d",strlen(x));


int  a=0;
int  b=c=d=0;
int  e=INT_MAX=0;
b=c=5;

a,b=b,a;
a,b=4;
a,b,c=c,b,a;
return 0;
}
