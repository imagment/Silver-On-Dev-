#!/bin/bash

rm build.cpp

for file in *.cpp; do
    if [[ -f "$file" ]]; then
        echo "Compiling $file..."
        g++ -o "${file%.cpp}" "$file"
        if [ $? -eq 0 ]; then
            echo "Compilation successful."
        else
            echo "Compilation failed. Exiting."
            exit 1
        fi
    fi
done

# Check if there is an executable named 'main' and execute it
if [ -x ./main ]; then
    echo "Executing ./main..."
    ./main
else
    echo "No executable named 'main' found."
fi

