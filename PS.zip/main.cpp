#include <iostream>
#include <fstream>
#include <cstring>
#include <cstdlib>
#include <vector>
#include <string>
#include <map>
#include <regex>

using namespace std;

map<string, string> header_defined_tokens; // Map to store token and its value
map<string, string> header_defined_functions; // Map to store function definitions

#define MAX_TOKEN_SIZE 1000
void parse_header(const string& header_path) {
    ifstream header_file(header_path);
    if (!header_file) {
        cerr << "Error opening header file: " << header_path << "\n";
        return;
    }

    string line;
    stringstream macro_stream;
    string current_macro_name;
    bool in_multiline_macro = false;

    // Regex to match #define statements: capturing both simple defines and function-like macros
    static const regex define_regex(R"(^\s*#\s*define\s+(\w+)\s*(\(.*\))?\s*(.*)?)");
    // Regex to match function declarations or definitions
    static const regex function_regex(R"(^\s*([\w\s\*\[\]]+?)\s+(\w+)\s*\(([^)]*)\)\s*(?:;|\{.*\})?$)");

    while (getline(header_file, line)) {
        // Check for continuation lines in multi-line macros
        if (in_multiline_macro) {
            if (regex_search(line, regex(R"(\s*\\\s*$)"))) {
                macro_stream << line.substr(0, line.find_last_not_of("\\") + 1); // Remove trailing backslash
                continue;
            } else {
                macro_stream << line;
                header_defined_tokens[current_macro_name] = macro_stream.str();
                in_multiline_macro = false;
                macro_stream.str("");
                macro_stream.clear();
                continue;
            }
        }

        smatch match;
        if (regex_search(line, match, define_regex)) {
            if (match.size() > 1) {
                string token = match.str(1);       // Token name
                string params = match.str(2);      // Macro parameters (if any)
                string value = match.str(3);       // Value or function body

                if (params.empty()) {
                    // If no parameters, it's a simple #define
                    header_defined_tokens[token] = value;
                } else {
                    // If parameters are present, it's a function-like macro
                    if (value.empty()) {
                        // Start of a multi-line macro
                        current_macro_name = token;
                        in_multiline_macro = true;
                        macro_stream << params << " " << value;
                    } else {
                        // Single-line function-like macro
                        header_defined_tokens[token] = params + " " + value;
                    }
                }
            }
        } else if (regex_search(line, match, function_regex)) {
            if (match.size() > 2) {
                string return_type = match.str(1); // Function return type
                string func_name = match.str(2);    // Function name
                string params = match.str(3);       // Parameters

                // Ensure it's a function by excluding macros and other non-function definitions
                if (header_defined_tokens.find(func_name) == header_defined_tokens.end()) {
                    // Combine return type and function details
                    header_defined_functions[func_name] = return_type + " " + func_name + "(" + params + ")";
                }
            }
        }
    }

    // Handle any remaining multi-line macro
    if (in_multiline_macro) {
        header_defined_tokens[current_macro_name] = macro_stream.str();
    }

    header_file.close();

    // Debug: Print the found tokens
    cout << "Defined Tokens:\n";
    for (const auto& [key, value] : header_defined_tokens) {
        cout << key << " = " << value << "\n";
    }

    // Debug: Print the found functions
    cout << "\nDefined Functions:\n";
    for (const auto& [key, value] : header_defined_functions) {
        cout << key << " = " << value << "\n";
    }
}
struct Variable {
    string name;
    string type;
    bool is_const; // Flag to indicate if the variable is constant
};

vector<Variable> variables;

const map<string, bool> keywords = {
    {"while", true}, {"if", true}, {"else", true}, {"switch", true}, {"case", true}, {"intify", true}
};

const map<string, bool> var_keywords = {
    {"int", true}, {"string", true}, {"double", true}, {"float", true}, {"bool", true},
    {"nat", true}, {"vec2", true}, {"free", true}, {"int32", true}, {"short", true}, {"long", true},
    {"unsigned", true}, {"bool", true}, {"list", true}, {"deque", true}, {"stat", true}
};

const map<string, bool> operators = {
    {"+", true}, {"-", true}, {"*", true}, {"/", true}, {"=", true}, {"==", true},
    {"+=", true}, {"-=", true}, {"*=", true}, {"/=", true}, {",", true}, {"&", true}
};

bool is_keyword(const string& str) {
    return keywords.find(str) != keywords.end();
}

bool is_operator(const string& str) {
    return operators.find(str) != operators.end();
}

bool is_variable(const string& str) {
    for (const auto& var : variables) {
        if (var.name == str) {
            return true;
        }
    }
    return false;
}

void addVariable(const string& name, const string& type, bool is_const) {
    variables.push_back({name, type, is_const});
}

bool is_var_keyword(const string& str) {
    return var_keywords.find(str) != var_keywords.end();
}

bool is_custom_operator(const string& str) {
    return str == "NOT" || str == "OR" || str == "AND";
}

void handle_custom_operator(const string& token, ofstream& output) {
    if (token == "NOT") {
        output << "!";
    } else if (token == "OR") {
        output << "||";
    } else if (token == "AND") {
        output << "&&";
    }
}

void handle_unknown_token(const string& token) {
    if (header_defined_tokens.find(token) == header_defined_tokens.end() &&
        header_defined_functions.find(token) == header_defined_functions.end() &&
        !is_variable(token) &&
        !is_keyword(token) &&
        !is_operator(token) &&
        !is_custom_operator(token)) {
        cerr << "Error: Unknown token: " << token << "\n";
        exit(1); // Terminate on error
    }
}

bool is_defined_token(const string& token) {
    return header_defined_tokens.find(token) != header_defined_tokens.end() || header_defined_functions.find(token) != header_defined_functions.end();
}

vector<string> read_header_config(const string& filename) {
    vector<string> configStrings;
    ifstream configFile(filename);
    string line;

    if (!configFile.is_open()) {
        cerr << "Error: Unable to open configuration file " << filename << endl;
        return configStrings;
    }

    while (getline(configFile, line)) {
        configStrings.push_back(line);
    }

    configFile.close();
    return configStrings;
}

void generate_cpp_code(ifstream& input, ofstream& output) {
    vector<string> headers;
    char c;
    string type;
    bool isVariable = false;
    bool isDeclaringVariable = false;
    bool variableDeclaredInCurrentStatement = false;
    bool isConstant = false;
    bool in_repeat_block = false;
    bool in_switch_block = false;
    bool is_case = false;
    bool is_default = false;
    bool isExecute = false;

    // Read configuration file
    vector<string> configStrings = read_header_config("headerConfig.txt");

    while (input.get(c)) {
        if (c == '#') {
            string command;
            do {
                command += c;
                c = input.get();
            } while (!isspace(c) && c != EOF);

            if (command == "#add") {
                string header;
                while (isspace(c)) c = input.get();

                if (c == '<') {
                    header += "<";
                    while ((c = input.get()) != '>' && c != EOF) {
                        header += c;
                    }
                    header += '>';

                    if (!configStrings.empty()) {
                        string header_path = header.substr(1, header.size() - 2);
                        string combined = configStrings[0] + header_path;
                        parse_header(combined);
                    }

                } else if (c == '"') {
                    header += '"';
                    while ((c = input.get()) != '"' && c != EOF) {
                        header += c;
                    }
                    header += '"';

                    string header_path = header.substr(1, header.size() - 2);
                    parse_header(header_path);
                }

                headers.push_back(header);
                input.get(c); // Continue reading
                continue;
            }

        } else if(!isspace(c)){
            input.unget(); // Put back the character
            break;
        }
    }

    output << "#include <stdio.h>\n";
    output << "#include <iostream>\n";
    output << "#include <cstdlib>\n";
    for (const auto& header : headers) {
        output << "#include " << header << "\n";
    }
    output << "using namespace std;\n";
    output << "int main() {\n";

    bool in_comment = false;
    bool in_multiline_comment = false;
    bool last_char_was_separator = true;
    bool isEmptyLine = true;
    bool justDeclared = false;

    while (input.get(c)) {
        if (in_comment) {
            if (c == '\n') {
                in_comment = false;
                isEmptyLine = true;
                output << "\n";
            }
            continue;
        }

        if (justDeclared) {
            if (c != '=' && c != ',') {  // Handle the case where there is no '=' or ',' after a declaration
                output << "=0";
                justDeclared = false;
            } else if (c == ',') {
                output << ", ";
                justDeclared = false;
                isDeclaringVariable = true;  // Handle multiple variable declarations
                continue;
            }
        }

        if (in_multiline_comment) {
            if (c == '*' && input.peek() == '/') {
                in_multiline_comment = false;
                input.get(c); // Consume the '/'
                continue; // Skip the '/'
            }
            continue; // Skip characters in the comment
        }

        if (c == '/') {
            if (input.peek() == '*') {
                in_multiline_comment = true;
                input.get(c); // Consume the '*'
                continue; // Skip the '*'
            } else {
                output << "/";
                continue;
            }
        }

        if (c == '!') {
            in_comment = true;
            continue;
        }

        if (isalpha(c) || c == '_') {
            last_char_was_separator = false;
            isEmptyLine = false;
            string token;
            do {
                token += c;
            } while ((isalnum(c = input.get()) || c == '_') && token.size() < MAX_TOKEN_SIZE - 1);
            input.unget();

            if (isExecute) {
                if (token == "done") {
                    output << "}\n";
                    isExecute = false;
                    last_char_was_separator = true;
                    continue;
                }
                output << token;
                continue;
            }

            if (token == "execute") {
                output << "{\n";
                isExecute = true;
                last_char_was_separator = true;
                continue;
            } else if (token == "repeat") {
                output << "do {\n";
                in_repeat_block = true;
                last_char_was_separator = true;
            } else if (token == "during") {
                output << "} while ";
                in_repeat_block = true;
            } else if (token == "done") {
                output << "}\n";
                last_char_was_separator = true;
            } else if (token == "switch") {
                output << "switch (";
                in_switch_block = true;
            } else if (token == "case") {
                if (in_switch_block) {
                    output << ") {\ncase ";
                    is_case = true;
                    last_char_was_separator = true;
                }
            } else if (token == "default") {
                output << "} default:\n";
                is_default = true;
            } else if (token == "break") {
                output << "break;\n";
            } else if (token == "continue") {
                output << "continue;\n";
            } else if (token == "prompt") {
                output << "printf";
            } else if (token == "ln") {
                output << "ln_printf";
            } else if (token == "scan") {
                output << "scanf";
            } else if (token == "get") {
                output << "input";
            } else if (is_var_keyword(token)) {
                output << token << " ";
                isVariable = true;
                isDeclaringVariable = true;
                variableDeclaredInCurrentStatement = true;
                type = token;
            } else if (token == "const") {
                output << "const ";
                isConstant = true;
            } else if (token == "for") {
                output << "for ";
            } else if (token == "do") {
                last_char_was_separator = true;
                output << "{\n";
            } else if (is_keyword(token)) {
                output << token;
            } else if (is_variable(token)) {
                output << token;
                isVariable = false;
                isDeclaringVariable = false;
                variableDeclaredInCurrentStatement = false;
            } else if (is_custom_operator(token)) {
                handle_custom_operator(token, output);
                isDeclaringVariable = false;
            } else if (is_defined_token(token)) {
                printf("dd");
                output << token;
                continue;
            } else if (isVariable) {
                output << token;
                addVariable(token, type, isConstant);
                justDeclared = true;
                isConstant = false;
            } else {
                handle_unknown_token(token);
            }
            continue;
        }

        if (isdigit(c)) {
            string token;
            do {
                token += c;
            } while (isdigit(c = input.get()) && token.size() < MAX_TOKEN_SIZE - 1);
            input.unget();
            output << token;
            last_char_was_separator = false;
            continue;
        }
        if (c == '"') {
            output << '"';
            isEmptyLine = false;
            while ((c = input.get()) != '"' && c != EOF) {
                if (c == '\\') {
                    output << '\\';
                    c = input.get();
                }
                output << c;
            }
            output << '"';
            last_char_was_separator = false;
            continue;
        }

        if (strchr("+-*/=,!<>", c)) {
            string op(1, c);
            if (strchr("=<>!", c) && input.peek() == '=') {
                op += '=';
                input.get(c); // Consume the '='
            }

            justDeclared = false;
            if (c == '=') isVariable = 2;
            if (c == ',' && isVariable == 1) {
                output << "=0, ";
                continue;
            }
            output << op;
            last_char_was_separator = true;
            continue;
        }

        if (c == '(' || c == '[' || c == '{') {
            if (!is_case && !is_default && !in_switch_block) {
                output << c;
            } else {
                is_case = false;
                is_default = false;
                in_switch_block = false;
            }
        } else if (c == ')' || c == ']' || c == '}') {
            output << c;
        } else if (c == '\n' || c == ';') {
            isVariable = false;
            if (!in_repeat_block) {
                if (!last_char_was_separator) {
                    output << ";\n";
                } else {
                    output << "\n";
                }
            }
            isEmptyLine = true;
            last_char_was_separator = true;
            variableDeclaredInCurrentStatement = false;
            in_repeat_block = false;
        } else if (c == ',') {
            if (isVariable) {
                output << ", ";
                continue;
            }
            output << c;
        } else {
            output << c;
        }
    }

    output << "return 0;\n";
    output << "}\n";
}


int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr);
    cout.tie(nullptr);

    const string input_file_path = "start.tch";
    const string output_file_path = "build.cpp";

    cout << "Efficacité V 0.2.3\n\n";

    ifstream input(input_file_path);
    if (!input) {
        cerr << "Error opening input file\n";
        return 1;
    }

    ofstream output(output_file_path);
    if (!output) {
        cerr << "Error opening output file\n";
        return 1;
    }

    generate_cpp_code(input, output);

    cout << "Transpiled Successfully.\n";

    return 0;
}
