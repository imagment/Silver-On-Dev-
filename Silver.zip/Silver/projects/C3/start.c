#include <stdio.h>
int main(void){
	print("Hello World");
}
