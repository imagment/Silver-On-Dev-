#ifndef GAME_LOGIC_H
#define GAME_LOGIC_H

// Function to find and return the content of a text file in the "arts" folder
char* art(const char* filename);

#endif // GAME_LOGIC_H
