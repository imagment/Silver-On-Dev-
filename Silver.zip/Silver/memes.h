#ifndef MEMES_H
#define MEMES_H

// Function to get a random ASCII art meme
const char* get_random_meme();

#endif // MEMES_H
