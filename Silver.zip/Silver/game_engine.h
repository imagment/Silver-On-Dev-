#ifndef GAME_ENGINE_H
#define GAME_ENGINE_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <dirent.h>

void compile_code(const char *code, const char *output_path);
void run_game(const char *game_code);
void save_user_code(const char *username, const char *project_name, const char *code);
char* load_user_code(const char *username, const char *project_name);
void list_projects();

#endif 
