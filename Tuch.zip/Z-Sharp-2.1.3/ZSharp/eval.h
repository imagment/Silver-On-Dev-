#ifndef EVAL_H
#define EVAL_H

float evaluate(const std::string& t);

#endif