#!/bin/bash

# Compile all .c files in the current directory into one executable named 'main'
gcc -o main *.c

# Check if the compilation was successful
if [ $? -eq 0 ]; then
    echo "[+] Loading..."
    # Run the compiled program
    ./main
else
    echo "[!] Error had been occured."
fi
