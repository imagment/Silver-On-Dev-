#include "compiler.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <unistd.h>
#include <dirent.h>
#include <sys/stat.h>
#include <dlfcn.h>
#define ALLOWED_HEADER "silver.h"
#define MAX_CODE_LENGTH 3999
#define DAYS_LIMIT 2

#define MAX_LINE_LENGTH 8000
#define TEMP_FILE "compiled.c"
#define BACKUP_DIR "./temp/"
#define MAX_BACKUPS 10


int debugmode = 0, torchmode = 0;
char header_inclusions[MAX_LINE_LENGTH * 1000] = "";
int mode=1;

// Function to create a backup

int create_dir(const char *path) {
    char cmd[1024];
    snprintf(cmd, sizeof(cmd), "mkdir -p \"%s\"", path);
    return system(cmd);
}

void create_backup(const char *project_name) {
    char project_dir[1024];
    char backup_dir[1024];
    char timestamp[128];
    time_t now = time(NULL);
    struct tm *t = localtime(&now);

    // Define the project directory
    snprintf(project_dir, sizeof(project_dir), "./projects/%s", project_name);

    // Check if the project directory exists
    struct stat st;
    if (stat(project_dir, &st) != 0 || !S_ISDIR(st.st_mode)) {
        printf("\033[0;31m[!] Project directory does not exist.\033[0m\n");
        return;
    }

    // Create a timestamp for the backup directory
    strftime(timestamp, sizeof(timestamp), "%Y%m%d_%H%M%S", t);
    snprintf(backup_dir, sizeof(backup_dir), "%s/%s/%s", BACKUP_DIR, project_name, timestamp);

    // Create the backup directory including any intermediate directories
    if (create_dir(backup_dir) != 0) {
        perror("Backup directory creation failed");
        return;
    }

    // Copy all files from the project directory to the backup directory
    // Rename .c files to .c.temp during the backup process
    char command[2048];
    snprintf(command, sizeof(command),
             "find \"%s\" -type f -name '*.c' -exec bash -c 'cp \"{}\" \"%s/$(basename {} .c).c.temp\"' \\;",
             project_dir, backup_dir);
    int result = system(command);
    if (result != 0) {
        printf("\033[0;31m[!] Backup failed: File copy failed.\033[0m\n");
        return;
    }

    // Copy other files (non-.c) normally
    snprintf(command, sizeof(command),
             "find \"%s\" -type f ! -name '*.c' -exec cp {} \"%s/\" \\;",
             project_dir, backup_dir);
    result = system(command);
    if (result != 0) {
        printf("\033[0;31m[!] Backup failed: File copy failed.\033[0m\n");
        return;
    }

    // Manage the number of backups
    snprintf(command, sizeof(command),
             "find \"%s/%s\" -maxdepth 1 -type d -name '20*' | sort | head -n -%d | xargs -r rm -rf",
             BACKUP_DIR, project_name, MAX_BACKUPS);
    result = system(command);
    if (result != 0) {
        printf("\033[0;31m[!] Backup management failed: Deleting old backups failed.\033[0m\n");
    }
}

void manage_backups() {
    DIR *d = opendir(BACKUP_DIR);
    if (d == NULL) {
        perror("Could not open backup directory");
        return;
    }

    char *backup_files[MAX_BACKUPS + 1];
    int backup_count = 0;

    struct dirent *dir;
    while ((dir = readdir(d)) != NULL) {
        if (dir->d_type == DT_DIR && strstr(dir->d_name, "20")) { // Adjusted to handle years in the 2000s
            if (backup_count < MAX_BACKUPS) {
                backup_files[backup_count] = strdup(dir->d_name);
                backup_count++;
            } else {
                free(backup_files[MAX_BACKUPS]);
                backup_files[MAX_BACKUPS] = strdup(dir->d_name);
            }
        }
    }
    closedir(d);

    // Sort backups by creation time (reverse chronological order)
    qsort(backup_files, backup_count, sizeof(char*), (int (*)(const void*, const void*))strcmp);

    // Delete old backups if there are more than MAX_BACKUPS
    for (int i = 0; i < backup_count - MAX_BACKUPS; ++i) {
        char rm_command[512];
        snprintf(rm_command, sizeof(rm_command), "rm -rf \"%s/%s\"", BACKUP_DIR, backup_files[i]);
        printf("[+] Running command: %s\n", rm_command);
        if (system(rm_command) == -1) {
            printf("\033[0;31m[!] Error executing command\033[0m\n");
        }
        free(backup_files[i]);
    }

    // Free remaining backup entries
    for (int i = backup_count - MAX_BACKUPS; i < backup_count; ++i) {
        free(backup_files[i]);
    }
}
char *escape_art(const char *art) {
  if (art == NULL)
    return NULL;

  size_t length = strlen(art);
  size_t new_length = 0;

  // Calculate the new length after escaping
  for (size_t i = 0; i < length; ++i) {
    if (art[i] == '\\' || art[i] == '\n') {
      new_length += 2; // "\\" or "\\n"
    } else {
      new_length += 1;
    }
  }

  // Allocate memory for the new string
  char *escaped_art = malloc(new_length + 1); // +1 for null terminator
  if (escaped_art == NULL) {
    fprintf(stderr, "Memory allocation failed\n");
    return NULL;
  }

  size_t j = 0;
  for (size_t i = 0; i < length; ++i) {
    if (art[i] == '\\') {
      escaped_art[j++] = '\\';
      escaped_art[j++] = '\\';
    } else if (art[i] == '\n') {
      escaped_art[j++] = '\\';
      escaped_art[j++] = 'n';
    } else {
      escaped_art[j++] = art[i];
    }
  }
  escaped_art[j] = '\0';

  return escaped_art;
}

const char* skip_quoted(const char* p) {
    char quote_char = *p++;
    while (*p && *p != quote_char) {
        if (*p == '\\' && *(p + 1)) {
            p++; // Skip escaped character
        }
        p++;
    }
    return *p ? p + 1 : p; // Skip closing quote
}

// Function to split arguments considering quoted sections
int split_args(const char* input, char args[3][MAX_LINE_LENGTH]) {
    const char *start = input, *p = input;
    int arg_index = 0;

    while (*p && arg_index < 3) {
        if (*p == '\'' || *p == '"') {
            p = skip_quoted(p);
        } else if (*p == ',') {
            if (arg_index < 3) {
                strncpy(args[arg_index], start, p - start);
                args[arg_index][p - start] = '\0';
                arg_index++;
                start = p + 1;
            }
            p++;
        } else {
            p++;
        }
    }

    if (arg_index < 3 && *start) {
        strncpy(args[arg_index], start, p - start);
        args[arg_index][p - start] = '\0';
        arg_index++;
    }

    return arg_index;
}

void transform_for_loop(const char *input, char *output, int line_number) {
    int x, y, z;
    char args[3][MAX_LINE_LENGTH];
    
    if (sscanf(input, "for(%d,%d)", &x, &y) == 2) {
        snprintf(output, MAX_LINE_LENGTH, "for(int i=%d; i<=%d; i++){", x, y);
    } else if (sscanf(input, "for(%d,%d,%d)", &x, &y, &z) == 3) {
        snprintf(output, MAX_LINE_LENGTH, "for(int i=%d; i<=%d; i+=%d){", x, y, z);
    } else if (sscanf(input, "for(%d)", &x) == 1) {
        snprintf(output, MAX_LINE_LENGTH, "for(int i=0; i<%d; i++){", x);
    } else {
        int num_args = split_args(input + 4, args);
        if (num_args == 3) {
            snprintf(output, MAX_LINE_LENGTH, "for(%s; %s; %s){", args[0], args[1], args[2]);
        } else {
            printf("\033[0;31m[!] Invalid format of  'for' in line %d: %s\033[0m\n", line_number, input);
        }
    }
}
const char *create_art2(const char *parameter) {
  char filename[256];
  snprintf(filename, sizeof(filename), "./arts/%s.txt", parameter);
  FILE *file = fopen(filename, "r");
  if (file == NULL) {
    printf("\033[0;31mInvalid art name: %s\n", parameter);
    return NULL;
  }

  // Determine file size
  fseek(file, 0, SEEK_END);
  long file_size = ftell(file);
  rewind(file); // Move file pointer back to the beginning

  // Allocate memory dynamically
  char *art = malloc(file_size + 1); // +1 for null terminator
  if (art == NULL) {
    fclose(file);
    return NULL;
  }

  // Read the file content
  size_t bytes_read = fread(art, 1, file_size, file);
  if (ferror(file)) {
    free(art);
    fclose(file);
    return NULL;
  }
  art[bytes_read] = '\0'; // Null-terminate the string
  fclose(file);
  return art;
}

void execute_prompt(const char *message) {
    printf("%s\n", message);
}

void add_header(const char *header_name) {
    if (strlen(header_inclusions) + strlen(header_name) + 10 >= sizeof(header_inclusions)) {
        fprintf(stderr, "\033[0;31m[!] Error: Header buffer is full.\033[0m\n");
        return;
    }
    snprintf(header_inclusions + strlen(header_inclusions), sizeof(header_inclusions) - strlen(header_inclusions), "#include <%s>\n", header_name);
}

void write_headers_to_file(FILE *temp_file) {
    fseek(temp_file, 0, SEEK_SET);
    fprintf(temp_file, "%s", header_inclusions);
}


void clear_screen() {
#ifdef _WIN32
    system("cls");
#else
    system("clear");
#endif
}
char* read_with_replacement(const char *filename) {
    FILE *file = fopen(filename, "r");
    if (!file) {
        perror("Failed to open file");
        return NULL;
    }

    // Determine file size
    fseek(file, 0, SEEK_END);
    long length = ftell(file);
    fseek(file, 0, SEEK_SET);

    // Allocate memory dynamically
    char *buffer = (char *)malloc(length + 1); // +1 for null terminator
    if (!buffer) {
        perror("Failed to allocate memory");
        fclose(file);
        return NULL;
    }

    fread(buffer, 1, length, file);
    buffer[length] = '\0'; // Null-terminate the string
    fclose(file);

    // Allocate memory for the modified content
    char *modified_content = (char *)malloc(length * 2); // Extra space for replacements
    if (!modified_content) {
        perror("Failed to allocate memory");
        free(buffer);
        return NULL;
    }

    char *src = buffer;
    char *dest = modified_content;
    int in_quotes = 0; // Flag to track whether we are inside quotes

    while (*src) {
        if (*src == '"') {
            in_quotes = !in_quotes; // Toggle the in_quotes flag
            *dest++ = *src++;
        } else if (!in_quotes && *src == ';') {
            *dest++ = '\n'; // Replace ; with new line
            src++;
        } else {
            *dest++ = *src++;
        }
    }
    *dest = '\0';

    free(buffer);
    return modified_content;
}
void unescape_string(char *dest, const char *src) {
    while (*src) {
        if (*src == '\\' && *(src + 1)) {
            src++;
            switch (*src) {
                case 'n':
                    *dest = '\n';
                    break;
                case 't':
                    *dest = '\t';
                    break;
                case 'r':
                    *dest = '\r';
                    break;
                case '\\':
                    *dest = '\\';
                    break;
                case '\"':
                    *dest = '\"';
                    break;
                case '\'':
                    *dest = '\'';
                    break;
                case '0':
                    *dest = '\0';
                    break;
                default:
                    *dest = *src;
                    break;
            }
        } else {
            *dest = *src;
        }
        dest++;
        src++;
    }
    *dest = '\0';
}

void parse_and_execute_line(const char *line, const int line_number, FILE *temp_file, int *in_executes_block) {
    while (*line == ' ' || *line == '\t') {
        line++;
    }

    if (strcmp(line, "") == 0 || strcmp(line, "------------------------------------------------") == 0) {
        return;
    }

    if (*in_executes_block) {
        if (strcmp(line, "done") == 0) {
            fprintf(temp_file, "}\n");
            *in_executes_block = 0;
        } else {
            fprintf(temp_file, "%s\n", line);
        }
        return;
    }

    char cleaned_line[MAX_LINE_LENGTH];
    char *dst = cleaned_line;
    int in_quotes = 0;

    while (*line) {
        if (*line == '"') {
            in_quotes = !in_quotes;
        }

        if (!in_quotes && (*line == '(' || *line == ')')) {
            if (dst > cleaned_line && *(dst - 1) == ' ') {
                dst--;
            }
            *dst++ = *line++;

            if (*line == ' ') {
                while (*line == ' ') {
                    line++;
                }
            }
        } else {
            *dst++ = *line++;
        }
    }

    *dst = '\0';

     if (strncmp(cleaned_line, "for(", 4) == 0) {
        char transformed_line[MAX_LINE_LENGTH];
        transform_for_loop(cleaned_line, transformed_line,line_number);
        fprintf(temp_file, "%s\n", transformed_line);

      }
      else if (strncmp(cleaned_line, "while(", 6) == 0) {
        fprintf(temp_file, "%s {\n", cleaned_line);
      } else if(strcmp(cleaned_line,"rend")==0){
      	fprintf(temp_file, "while(1) {\n", cleaned_line);
      }
      else if (strncmp(cleaned_line, "if(", 3) == 0) {
          fprintf(temp_file, "%s {\n", cleaned_line);
      }
      else if (strncmp(cleaned_line, "elif(", 5) == 0) {
          fprintf(temp_file, "} %s {\n", cleaned_line);
      }
      else if (strcmp(cleaned_line, "else") == 0) {
            fprintf(temp_file, "else{\n");
        }
      else if (strcmp(cleaned_line, "break") == 0) {
          fprintf(temp_file, "break;\n");
      } else if(strcmp(cleaned_line,"continue")==0){
      	fprintf(temp_file, "continue;\n");
      } else if (strncmp(cleaned_line, "art(", 4) == 0) {
          char parameter[MAX_LINE_LENGTH];
          // Use sscanf to extract the parameter without the quotes
          if (sscanf(cleaned_line + 4, "\"%[^\"]\"", parameter) == 1) {
            // Ensure create_art2 is declared and defined elsewhere
            char *art = strdup(create_art2(parameter));
            if (art != NULL) {
              char *escaped_art = escape_art(art);
              if (escaped_art != NULL) {
                fprintf(temp_file, "printf(\"%s\\n\");\n", escaped_art);
                free(escaped_art); // Free the escaped art
              }
              free(art); // Remember to free allocated memory for the original art
            }
          }
        }else if (strncmp(cleaned_line, "op ", 3) == 0 && (strstr(cleaned_line, "++") || strstr(cleaned_line, "--") ||
        strstr(cleaned_line, "+=") || strstr(cleaned_line, "-=") ||
        strstr(cleaned_line, "*=") || strstr(cleaned_line, "/=") ||
        strstr(cleaned_line, "=") || strstr(cleaned_line, "<<=") || strstr(cleaned_line, ">>=") || strstr(cleaned_line, "&=") || strstr(cleaned_line, "|="))) {

        fprintf(temp_file, "%s;\n", cleaned_line + 3);
    } else if (strncmp(cleaned_line, "#add ", 5) == 0) {
        char header_file[MAX_LINE_LENGTH];
        if (sscanf(cleaned_line + 5, "%[^\n]", header_file) != 1) {
            printf("\033[0;31m[!] Error: Invalid format for #add command on line %d: %s\033[0m\n", line_number, cleaned_line);
        } else {
            add_header(header_file);
        }
    } else if (strcmp(cleaned_line, "clear") == 0) {
#ifdef _WIN32
        fprintf(temp_file, "system(\"cls\");\n");
#else
        fprintf(temp_file, "system(\"clear\");\n");
#endif
    } else if (strcmp(cleaned_line, "credits") == 0) {
        fprintf(temp_file, "printf(\"\\n\\n This Engine (Silver) is made by Imagment Studios.\\n\");\n");
    } else if (strncmp(cleaned_line, "execute ", 8) == 0) {
        char code[MAX_LINE_LENGTH];
        if (sscanf(cleaned_line + 8, "%[^\n]", code) != 1) {
            printf("\033[0;31m[!] Error: Invalid format for execute command on line %d: %s\033[0m\n", line_number, cleaned_line);
        } else {
            fprintf(temp_file, "{%s}\n", cleaned_line + 8);
        }
    } else if (strncmp(cleaned_line, "debug(", 6) == 0) {
        char message[MAX_LINE_LENGTH];
        size_t len = strlen(cleaned_line);

        if (cleaned_line[len - 1] != ')') {
            printf("\033[0;31m[!] Error: Missing closing parenthesis for debug command on line %d: %s\033[0m\n", line_number, cleaned_line);
        } else {
            // Remove the trailing ')'
            cleaned_line[len - 1] = '\0';

            // Parse the message string between the quotes
            if (sscanf(cleaned_line + 6, "\"%[^\"]\"", message) != 1) {
                printf("\033[0;31m[!] Error: Invalid format for debug command on line %d: %s\033[0m\n", line_number, cleaned_line);
            } else if (debugmode) {
                fprintf(temp_file, "printf(\"\\033[0;32m\\nDEBUG: %s\\033[0m\\n\");\n", message);
            }
        }
    } else if (strncmp(cleaned_line, "debug_warning(", 14) == 0) {
        char message[MAX_LINE_LENGTH];
        size_t len = strlen(cleaned_line);

        if (cleaned_line[len - 1] != ')') {
            printf("\033[0;31m[!] Error: Missing closing parenthesis for debug_warning command on line %d: %s\033[0m\n", line_number, cleaned_line);
        } else {
            // Remove the trailing ')'
            cleaned_line[len - 1] = '\0';

            // Parse the message string between the quotes
            if (sscanf(cleaned_line + 14, "\"%[^\"]\"", message) != 1) {
                printf("\033[0;31m[!] Error: Invalid format for debug_warning command on line %d: %s\033[0m\n", line_number, cleaned_line);
            } else if (debugmode) {
                fprintf(temp_file, "printf(\"\\033[0;33m\\nWARNING: %s\\033[0m\\n\");\n", message);
            }
        }
    } else if (strncmp(cleaned_line, "debug_error(", 12) == 0) {
        char message[MAX_LINE_LENGTH];
        size_t len = strlen(cleaned_line);

        if (cleaned_line[len - 1] != ')') {
            printf("\033[0;31m[!] Error: Missing closing parenthesis for debug_error command on line %d: %s\033[0m\n", line_number, cleaned_line);
        } else {
            // Remove the trailing ')'
            cleaned_line[len - 1] = '\0';

            // Parse the message string between the quotes
            if (sscanf(cleaned_line + 12, "\"%[^\"]\"", message) != 1) {
                printf("\033[0;31m[!] Error: Invalid format for debug_error command on line %d: %s\033[0m\n", line_number, cleaned_line);
            } else if (debugmode) {
                fprintf(temp_file, "printf(\"\\033[0;31m\\nERROR: %s\\033[0m\\n\");\n", message);
            }
        }
    }
           
       else if (strncmp(cleaned_line, "prompt(", 7) == 0) {
           char format[MAX_LINE_LENGTH];
           char arguments[MAX_LINE_LENGTH] = ""; // Initialize to empty string
           int parsed;

           // Check for the end of the command format
           size_t len = strlen(cleaned_line);
           if (cleaned_line[len - 1] != ')') {
               printf("\033[0;31m[!] Error: Missing closing parenthesis for prompt command on line %d: %s\033[0m\n", line_number, cleaned_line);
           } else {
               // Remove the trailing ')'
               cleaned_line[len - 1] = '\0';

               // Parse the format string between the quotes and check for additional arguments
               parsed = sscanf(cleaned_line + 7, "\"%[^\"]\"%s", format, arguments);

               if (parsed < 1) {
                   printf("\033[0;31m[!] Error: Invalid format for prompt command on line %d: %s\033[0m\n", line_number, cleaned_line);
               } else {
                   // Check if arguments were parsed
                   if (parsed == 1 || strlen(arguments) == 0) {
                       fprintf(temp_file, "printf(\"%s\");\n", format);
                   } else {
                       // Remove any leading or trailing whitespace from arguments
                       char clean_arguments[MAX_LINE_LENGTH];
                       sscanf(arguments, " %s", clean_arguments);
                       fprintf(temp_file, "printf(\"%s\", %s);\n", format, clean_arguments);
                   }
               }
           }
       }


       
       else if (strncmp(cleaned_line, "executes", 8) == 0) {
        fprintf(temp_file, "{\n");
        *in_executes_block = 1;
    } else if (strncmp(cleaned_line, "int ", 4) == 0) {
        fprintf(temp_file, "int %s;\n", cleaned_line + 4);
    } else if (strncmp(cleaned_line, "long ", 5) == 0) {
        fprintf(temp_file, "long long int %s;\n", cleaned_line + 5);
    } else if (strncmp(cleaned_line, "char ", 5) == 0) {
        fprintf(temp_file, "char %s;\n", cleaned_line + 5);
    } else if (strncmp(cleaned_line, "float ", 6) == 0) {
        fprintf(temp_file, "double %s;\n", cleaned_line + 6);
    } else if (strncmp(cleaned_line, "num ", 4) == 0) {
        fprintf(temp_file, "unsigned long long int %s;\n", cleaned_line + 4);
    } else if (strcmp(cleaned_line, "done") == 0) {
        fprintf(temp_file, "}\n");
    } else if (cleaned_line[0] != '!') {
        printf("\033[0;31m[!] Error: Invalid command on line %d: %s\033[0m\n", line_number, cleaned_line);
    } else {
        if (strcmp(cleaned_line, "!Allowdebug") == 0) {
            debugmode = 1;
        } else if (strcmp(cleaned_line, "!Disallowdebug") == 0) {
            debugmode = 0;
        } else if (strcmp(cleaned_line, "!TorchMyWay") == 0) {
            torchmode = 1;
        }
    }
}

int check_file_size(const char *file_path, size_t max_size) {
    FILE *file = fopen(file_path, "r");
    if (file == NULL) {
        perror("Error opening file");
        return -1;
    }

    fseek(file, 0, SEEK_END);
    long file_size = ftell(file);
    fclose(file);

    if (file_size == -1) {
        perror("Error getting file size");
        return -1;
    }

    return (file_size > (long)max_size) ? 1 : 0;
}

int check_no_external_includes(const char *file_path) {
    FILE *file = fopen(file_path, "r");
    if (file == NULL) {
        perror("Error opening file");
        return -1;
    }

    char line[256];
    while (fgets(line, sizeof(line), file)) {
        // Check for include directives
        if (strncmp(line, "#include", 8) == 0) {
            // Extract the filename from the #include directive
            char *start = strchr(line, '"');
            char *end = strrchr(line, '"');

            if (start != NULL && end != NULL && end > start) {
                // Extract the filename between quotes
                char include_file[256];
                strncpy(include_file, start + 1, end - start - 1);
                include_file[end - start - 1] = '\0';

                // Check file extensions and allowed headers
                char *ext = strrchr(include_file, '.');
                if (ext != NULL) {
                    if (strcmp(ext, ".c") == 0 || strcmp(ext, ".cpp") == 0 || 
                        strcmp(ext, ".cs") == 0 || strcmp(ext, ".hpp") == 0 || 
                        strcmp(ext, ".h") != 0 || (strcmp(include_file, ALLOWED_HEADER) != 0 && strcmp(include_file, "silver.h") != 0)) {
                        fclose(file);
                        return 1; // Disallowed external file found
                    }
                }
            }
        }
    }
    fclose(file);
    return 0;
}
int check_time(const char *line) {
    // Parse the date and time from the line
    struct tm file_time = {0};
    int year, month, day, hour, minute, second;
    if (sscanf(line, "%d-%d-%d %d:%d:%d\n",
               &year, &month, &day, &hour, &minute, &second) != 6) {
        fprintf(stderr, "Error parsing date and time\n");
        return -1;
    }

    file_time.tm_year = year - 1900; // tm_year is years since 1900
    file_time.tm_mon = month - 1;    // tm_mon is months since January
    file_time.tm_mday = day;
    file_time.tm_hour = hour;
    file_time.tm_min = minute;
    file_time.tm_sec = second;
    file_time.tm_isdst = -1; // Let mktime determine if DST is in effect

    // Convert file time to time_t
    time_t file_time_t = mktime(&file_time);
    if (file_time_t == -1) {
        perror("Error converting time");
        return -1;
    }

    // Get the current time
    time_t current_time = time(NULL);
    if (current_time == -1) {
        perror("Error getting current time");
        return -1;
    }

    // Calculate the difference in seconds
    double seconds_diff = difftime(current_time, file_time_t);

    // Convert seconds to days
    int days_diff = seconds_diff / (60 * 60 * 24);

    // Print debug info
    printf("File time: %ld, Current time: %ld, Seconds diff: %.0f, Days diff: %d\n",
           file_time_t, current_time, seconds_diff, days_diff);

    // Return 1 if more than 3 days have passed, otherwise 0
    return days_diff >= 3 ? 1 : 0;
}


void execute_torch(void) {
    // Compile the temporary file and capture errors
    int compile_status = system("gcc " TEMP_FILE " -o compiled 2>&1 | tee gcc_errors.txt");

    // Check if compilation was successful
    if (compile_status != 0) {
        printf("\033[0;31m[!] Compilation failed. Check gcc_errors.txt for details.\033[0m\n");
        return;
    }

    // Check if there were any errors
    FILE *error_file = fopen("gcc_errors.txt", "r");
    if (error_file) {
        fseek(error_file, 0, SEEK_END);
        long fsize = ftell(error_file);
        fseek(error_file, 0, SEEK_SET);

        if (fsize > 0) {
            char *error_content = malloc(fsize + 1);
            if (error_content) {
                fread(error_content, 1, fsize, error_file);
                error_content[fsize] = '\0';

                // Print errors if any
                printf("\033[0;31m[!] Compilation Errors:\033[0m\n%s\n", error_content);
                free(error_content);
            }
        }
        fclose(error_file);
    }

    // If there are no errors, execute the compiled file
    printf("[+] Executing the compiled file...\n");
    int exec_status = system("./compiled");

    // Check if execution was successful
    if (exec_status != 0) {
        printf("\033[0;31m[!] Execution failed.\033[0m\n");
    }

    // Note: Do not delete compiled.c
}



typedef void (*func_type)();

void compileC(const char *source_file, const char *mode) {
    //get current mode 
    if(strcmp(mode,"1")!=0){
        //check time, length, and external includes
        if(check_file_size(source_file,800)!=0){
            printf("\033[0;31mUser is ugly\nExiting Program...\033[0m");
            sleep(1);
            exit(0);
            return;
        }
        if(check_no_external_includes(source_file)!=0){
            printf("\033[0;31mIdiot have been detected\nExiting Program...\033[0m");
            sleep(1);
            exit(0);
            return;
        }
        if(check_time(mode)!=0){
            printf("\033[0;31mYou were late. Therefore, you are ugly\nExiting Program...\033[0m");
            sleep(1);
            exit(0);
            return;
        }
    }
    // Create a temporary executable file name
    char exec_file[256];
    snprintf(exec_file, sizeof(exec_file), "temp_exec");

    // Compile the source file into an executable
    char command[512];
    snprintf(command, sizeof(command), "gcc -o %s %s", exec_file, source_file);
    system(command);

    // Execute the resulting program
    snprintf(command, sizeof(command), "./%s", exec_file);
    system(command);

    // Clean up
    remove(exec_file);
}
void runPy(const char *project_name) {
    char command[512];
    snprintf(command, sizeof(command), "python3 ./projects/%s/start.py", project_name);
    system(command);
}

void runRuby(const char *project_name) {
    char command[512];
    snprintf(command, sizeof(command), "ruby ./projects/%s/start.rb", project_name);
    system(command);
}
void execute_script(char *project_name, char *mode) {
    
    create_backup(project_name);
    char path[512];
    snprintf(path, sizeof(path), "./projects/%s/start.c", project_name);
    if (strcmp(mode, "1") == 0) {
        // Compile the C code if mode is 1 or 2
        compileC(path,"1");
        return;
    }
  else if(strcmp(mode,"3")==0){
    	    char code_file_path[1024];
	    snprintf(code_file_path, sizeof(code_file_path), "./projects/%s/start.tch", project_name);

	    // Read the code file with replacement
	    char *modified_content = read_with_replacement(code_file_path);
	    if (modified_content == NULL) {
		printf("\033[0;31mError reading code file\033[0m\n");
		return;
	    }

	    // Create a temporary file for processing
	    FILE *temp_file = fopen(TEMP_FILE, "w+");
	    if (temp_file == NULL) {
		printf("\033[0;31mError creating temporary code file\033[0m\n");
		free(modified_content);
		return;
	    }

	    // Write necessary headers to the temporary file
	    write_headers_to_file(temp_file);

	    fprintf(temp_file, "#include <stdio.h>\n#include <stdlib.h>\n\n");
	    if (torchmode == 1) {
		fprintf(temp_file, "#include <math.h>\n");
		fprintf(temp_file, "#include <time.h>\n");
		fprintf(temp_file, "#include <string.h>\n");
		fprintf(temp_file, "#include <unistd.h>\n");
		fprintf(temp_file, "struct vector {\n");
		fprintf(temp_file, "int x;\n");
		fprintf(temp_file, "int y;\n");
		fprintf(temp_file, "int z;\n");
		fprintf(temp_file, "};\n");

		debugmode = 1;
	    }

	    fprintf(temp_file, "\n\nint main(void) {\n");

	    // Split the modified content into lines and process each line
	    char *line = strtok(modified_content, "\n");
	    int line_number = 0;
	    int in_executes_block = 0;

	    while (line != NULL) {
		line_number++;

		if (strlen(line) >= MAX_LINE_LENGTH) {
		    printf("\033[0;31m[!] Error: Line %d exceeds the maximum allowed length of %d characters.\033[0m\n", line_number, MAX_LINE_LENGTH - 1);
		} else {
		    parse_and_execute_line(line, line_number, temp_file, &in_executes_block);
		}

		line = strtok(NULL, "\n");
	    }

	    fprintf(temp_file, "return 0;\n}\n");
	    fclose(temp_file);

	    free(modified_content);

	    execute_torch();
	    return;
    }
    else if (strcmp(mode, "4") == 0) { // Python
        runPy(project_name);
        return;
    }
    else if (strcmp(mode, "5") == 0) { // Ruby
        runRuby(project_name);
        return;
    }
    else if (strcmp(mode, "6") == 0) { // Rust
        snprintf(path, sizeof(path), "./projects/%s/start.rs", project_name);
        char command[512];
        snprintf(command, sizeof(command), "rustc %s -o ./projects/%s/a.out", path, project_name);
        system(command);
        snprintf(command, sizeof(command), "./projects/%s/a.out", project_name);
     
        system(command);
        return;
    } 
    else if (strcmp(mode, "7") == 0) { // C++
        snprintf(path, sizeof(path), "./projects/%s/start.cpp", project_name);
        char command[512];
        snprintf(command, sizeof(command), "g++ %s -o ./projects/%s/a.out", path, project_name);
        system(command);
        snprintf(command, sizeof(command), "./projects/%s/a.out", project_name);
        system(command);
        return;
    }
    else{

	    compileC(path,mode);
	    return;
	    
               
    }
   

   
    
}



void executes(int line_number, const char *command) {
    FILE *temp_file = fopen(TEMP_FILE, "r+");
    if (temp_file == NULL) {
        printf("\033[0;31mError opening temporary code file\033[0m\n");
        return;
    }

    char buffer[MAX_LINE_LENGTH * 100];
    char *lines[MAX_LINE_LENGTH * 100]; // Assuming a maximum of 10000 lines.
    int current_line = 1;
    size_t len = 0;
    int total_lines = 0;

    // Read entire file content
    char *file_content = NULL;
    size_t file_size = 0;
    fseek(temp_file, 0, SEEK_END);
    file_size = ftell(temp_file);
    rewind(temp_file);
    file_content = (char *)malloc(file_size + 1);
    fread(file_content, 1, file_size, temp_file);
    file_content[file_size] = '\0';

    // Format the entire file content
   

    // Write the formatted content back to the file
    freopen(TEMP_FILE, "w", temp_file);
    fwrite(file_content, 1, strlen(file_content), temp_file);
    free(file_content);
    rewind(temp_file);

    // Now, proceed with updating the specific line
    while (fgets(buffer, sizeof(buffer), temp_file) != NULL) {
        lines[total_lines] = strdup(buffer); // Allocating memory for each line.
        total_lines++;
    }

    // Prepare the command to insert
    char formatted_command[MAX_LINE_LENGTH * 10];
    strcpy(formatted_command, command);

    // Update the specific line
    if (line_number <= total_lines) {
        free(lines[line_number - 1]); // Free the old line memory.
        lines[line_number - 1] = strdup(formatted_command); // Replace with the new command.
    } else {
        // Adding new lines if the line number is beyond current total lines
        while (current_line < line_number) {
            lines[total_lines++] = strdup("\n");
            current_line++;
        }
        lines[total_lines++] = strdup(formatted_command);
    }

    // Rewriting the file with updated lines
    freopen(TEMP_FILE, "w", temp_file);
    for (int i = 0; i < total_lines; i++) {
        fputs(lines[i], temp_file);
        free(lines[i]); // Freeing the memory after writing.
    }

    fclose(temp_file);
}


