#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_LINE_LENGTH 1000
#define MAX_COLS 10

char* lang(const char* search_string, int col) {
    FILE* fp;
    char line[MAX_LINE_LENGTH];
    static char translation[MAX_LINE_LENGTH];  // Static buffer for storing translation

    // Open the file for reading
    fp = fopen("languages.txt", "r");
    if (fp == NULL) {
        perror("Error opening file");
        exit(EXIT_FAILURE);
    }

    // Read lines until the desired string is found
    int found = 0;
    while (fgets(line, sizeof(line), fp) != NULL) {
        // Tokenize the line to get the first column
        char* token;
        token = strtok(line, "|");

        if (token != NULL && strcmp(token, search_string) == 0) {
            found = 1;
            // Extract the translation from the selected column
            int current_col = 0;
            while (token != NULL) {
                if (current_col == col) {
                    strcpy(translation, token);  // Copy translation to static buffer
                    break;
                }
                token = strtok(NULL, "|");
                current_col++;
            }
            break;
        }
    }

    if (!found) {
        strcpy(translation, "Translation not found");
    }

    // Close the file
    fclose(fp);

    return translation;
}

int main() {
    // Example usage: Get the translation for "Hello" in column 1 (second column)
    printf("Translation: %s\n", lang("Hello", 0));  // Assuming "languages.txt" has "Hello | 안녕하세요 | 你好"

    return 0;
}
