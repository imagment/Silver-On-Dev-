#include "memes.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#define MAX_ART_SIZE 1024 // Adjust size as needed

// Array of ASCII art memes
static const char* memes[] = {
"⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿\n⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿\n⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿\n⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿\n⣿⣿⣿⣿⡋⣹⣿⣿⣿⣿⣿⣿⣿⣏⠉⣿⣿⣿⣿⣿\n⣿⣿⣿⣿⣿⣿⣿⠹⣿⣿⡿⠏⣿⣿⣿⣿⣿⣿⣿⣿\n⣿⣿⣿⣿⣿⣿⣿⣷⣶⣶⣶⣿⣿⣿⣿⣿⣿⣿⣿⣿\n⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿\n⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿\n⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿\nHa Ha your code is screwed\n\n",
"\nAlright, grab some coffee\n"
"(  )   (   )  )\n"
" ) (   )  (  (\n"
"( )  (    ) )\n"
" ______________\n"
"<_____________ >___\n"
"|             |/ _ \\\n"
"|               | | |\n"
"|               |_| |\n"
"|             |\\___/\n"
"|             |    \n"
"\\____________/\n\n",
"\nTry joining our discord! : https://discord.gg/72TbP8G69k\n(Or you will have a curse that you will misspell a name of a variable.)\n"
};

// Number of ASCII art memes
#define NUM_MEMES (sizeof(memes) / sizeof(memes[0]))

const char* get_random_meme() {
    srand((unsigned int)time(NULL)); // Seed the random number generator
    int index = rand() % NUM_MEMES; // Get a random index
    return memes[index];
}

