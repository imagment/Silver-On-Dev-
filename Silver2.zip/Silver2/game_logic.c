#include "game_logic.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Function to find and return the content of a text file in the "arts" folder
char* art(const char* filename) {
    char path[256];
    snprintf(path, sizeof(path), "arts/%s.txt", filename);

    FILE *file = fopen(path, "r");
    if (!file) {
        perror("[!] Could not open file");
        return NULL;
    }

    // Determine the file size
    fseek(file, 0, SEEK_END);
    long file_size = ftell(file);
    fseek(file, 0, SEEK_SET);

    // Allocate memory for the content
    char *content = (char *)malloc(file_size + 1);
    if (!content) {
        perror("[!] Could not allocate memory");
        fclose(file);
        return NULL;
    }

    // Read the file content into the allocated memory
    fread(content, 1, file_size, file);
    content[file_size] = '\0'; // Null-terminate the string

    fclose(file);
    return content;
}
