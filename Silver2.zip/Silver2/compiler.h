
#ifndef COMPILER_H
#define COMPILER_H

void execute_script(char *project_name , char *mode);

#endif 
