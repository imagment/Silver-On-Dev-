#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <dirent.h>
#include <sys/stat.h>
#include <sys/types.h>
#include "compiler.h"
#include "memes.h"
#include <time.h>
#include <unistd.h>
#include <ctype.h>
#include <signal.h>
#include <sys/wait.h>

#define RED "\033[0;31m"
#define BACKUP_DIR "./temp"
#define MAX_BACKUPS 10

void clear_screen2() {
    #ifdef _WIN32
        system("cls");
    #else
        system("clear");
    #endif
}

void archive_project(const char *project_name) {
    char confirmation[256];
    printf("Are you sure you want to archive and delete the project '%s'? Enter the project name to confirm: ", project_name);
    fgets(confirmation, sizeof(confirmation), stdin);
    confirmation[strcspn(confirmation, "\n")] = '\0'; // Remove newline character

    if (strcmp(confirmation, project_name) == 0) {
        char archive_command[2048];
        snprintf(archive_command, sizeof(archive_command), "tar -czf ./temp/%s.tar.gz ./projects/%s && rm -rf ./projects/%s", project_name, project_name, project_name);
        system(archive_command);
        printf("Project archived and deleted.\nPlease start this program again.\n");
        exit(0);
    } else {
        printf("Project name mismatch. Archive operation cancelled.\n");
    }
}


int compare(const void *a, const void *b) {
    const char **pa = (const char **)a;
    const char **pb = (const char **)b;
    char *str_a = strdup(*pa);
    char *str_b = strdup(*pb);

    for (char *p = str_a; *p; ++p) *p = toupper(*p);
    for (char *p = str_b; *p; ++p) *p = toupper(*p);

    int result = strcmp(str_a, str_b);

    free(str_a);
    free(str_b);

    return result;
}

void list_projects() {
    clear_screen2(); 
    printf("Silver, C-based game engine\n\n");
    printf("%s", get_random_meme());

    DIR *d;
    struct dirent *dir;
    d = opendir("./projects");
    if (d) {
        char *project_names[100]; // Assuming there won't be more than 100 projects
        int project_count = 0;

        while ((dir = readdir(d)) != NULL) {
            if (dir->d_type == DT_DIR) {
                // Skip . and ..
                if (strcmp(dir->d_name, ".") != 0 && strcmp(dir->d_name, "..") != 0) {
                    project_names[project_count] = strdup(dir->d_name); // Copy the project name
                    project_count++;
                }
            }
        }
        closedir(d);

        if (project_count == 0) {
            printf("No projects available. Let's get started together!\n");
        } else {
            // Sort project names alphabetically
            qsort(project_names, project_count, sizeof(char *), compare);

            printf("[Available Projects]\n");
            for (int i = 0; i < project_count; i++) {
                printf("%d. %s\n", i + 1, project_names[i]);
                free(project_names[i]); // Free the allocated memory
            }
        }
    } else {
        printf("\033[0;31m[!] Could not open projects directory.\033[0m\n");
    }
}
void cleanup_project(const char *project_name) {
    char project_path[512];
    snprintf(project_path, sizeof(project_path), "./projects/%s", project_name);

    DIR *d;
    struct dirent *dir;
    d = opendir(project_path);
    if (d) {
        while ((dir = readdir(d)) != NULL) {
            if (dir->d_type == DT_REG) {
                char file_path[512];
                snprintf(file_path, sizeof(file_path), "%s/%s", project_path, dir->d_name);

                char command[1024];
                if (strstr(dir->d_name, ".c") != NULL || strstr(dir->d_name, ".cpp") != NULL) {
                    snprintf(command, sizeof(command), "clang-format -i \"%s\"", file_path);
                } else if (strstr(dir->d_name, ".py") != NULL) {
                    snprintf(command, sizeof(command), "black \"%s\"", file_path);
                } else if (strstr(dir->d_name, ".rb") != NULL) {
                    snprintf(command, sizeof(command), "rubocop -a \"%s\"", file_path);
                } else if (strstr(dir->d_name, ".rs") != NULL) {
                    snprintf(command, sizeof(command), "rustfmt \"%s\"", file_path);
                } else {
                    continue; // Skip files that do not match known extensions
                }

                printf("[+] Running command: %s\n", command);
                int result = system(command);
                if (result == -1) {
                    printf("\033[0;31m[!] Error executing command\033[0m\n");
                }
            }
        }
        closedir(d);
    } else {
        printf("\033[0;31m[!] Could not open project directory.\033[0m\n");
    }
}

void create_project(const char *project_name, const char *mode) {
    char project_path[512];
    snprintf(project_path, sizeof(project_path), "./projects/%s", project_name);

    if (mkdir(project_path, 0755) == -1) {
        printf("\033[0;31m[!] Error creating project directory\033[0m\n");
        return;
    }

    char code_file_path[512];
    FILE *code_file = NULL;

    if (strcmp(mode, "1") == 0 || strcmp(mode, "2") == 0) {
        snprintf(code_file_path, sizeof(code_file_path), "%s/start.c", project_path);
        code_file = fopen(code_file_path, "w");
        if (code_file != NULL) {
            fprintf(code_file, "#include <stdio.h>\n\nint main() {\n    printf(\"Hello, World!\\n\");\n    return 0;\n}\n");
        }
    } else if (strcmp(mode, "3") == 0) {
        snprintf(code_file_path, sizeof(code_file_path), "%s/start.tch", project_path);
        code_file = fopen(code_file_path, "w");
        if (code_file != NULL) {
            fprintf(code_file, "prompt(\"Hello, World!\")\n");
        }
    } else if (strcmp(mode, "4") == 0) {
        snprintf(code_file_path, sizeof(code_file_path), "%s/start.py", project_path);
        code_file = fopen(code_file_path, "w");
        if (code_file != NULL) {
            fprintf(code_file, "print(\"Hello, World!\")\n");
        }
    } else if (strcmp(mode, "5") == 0) {
        snprintf(code_file_path, sizeof(code_file_path), "%s/start.rb", project_path);
        code_file = fopen(code_file_path, "w");
        if (code_file != NULL) {
            fprintf(code_file, "puts 'Hello, World!'\n");
        }
    } else if (strcmp(mode, "6") == 0) {
        snprintf(code_file_path, sizeof(code_file_path), "%s/start.rs", project_path);
        code_file = fopen(code_file_path, "w");
        if (code_file != NULL) {
            fprintf(code_file, "fn main() {\n    println!(\"Hello, World!\");\n}\n");
        }
    } else if (strcmp(mode, "7") == 0) {
    snprintf(code_file_path, sizeof(code_file_path), "%s/start.cpp", project_path);
        code_file = fopen(code_file_path, "w");
        if (code_file != NULL) {
            fprintf(code_file, "#include <iostream>\n\nint main() {\n    std::cout << \"Hello, World!\" << std::endl;\n    return 0;\n}\n");
        }
        
    } else {
        printf("\033[0;31m[!] Invalid mode selected.\033[0m\n");
        return;
    }

    if (code_file == NULL) {
        printf("\033[0;31m[!] Error creating code file\033[0m\n");
        return;
    }
    fclose(code_file);

    // Save the mode or timestamp in a mode file
    char mode_file_path[512];
    snprintf(mode_file_path, sizeof(mode_file_path), "%s/mode.txt", project_path);

    char currenttime[20] = ""; // Increased buffer size to accommodate full timestamp
    time_t t = time(NULL);
    struct tm tm = *localtime(&t);
    FILE *mode_file = fopen(mode_file_path, "w");
    if (mode_file == NULL) {
        printf("\033[0;31m[!] Error creating mode file\033[0m\n");
        return;
    }

    // Format the timestamp
    strftime(currenttime, sizeof(currenttime), "%Y-%m-%d %H:%M:%S", &tm);

    if (strcmp(mode, "2") != 0) {
        fprintf(mode_file, "%s", mode);
    } else {
        fprintf(mode_file, "%s", currenttime);
    }

    fclose(mode_file);
}

void sigint_handler(int sig) {
    // Print message to indicate shell is exiting
    printf("\nExiting shell...\n");
    // Restore default signal handling and re-raise the signal to exit the shell
    signal(SIGINT, SIG_DFL);
    raise(SIGINT);
}

void get_command(const char *project_name) {
    char project_path[512];
    snprintf(project_path, sizeof(project_path), "./projects/%s", project_name);

    // Change working directory to the project directory
    if (chdir(project_path) != 0) {
        printf("\033[0;31m[!] Error changing directory to project directory\033[0m\n");
        return;
    }

    // Set up the SIGINT signal handler
    signal(SIGINT, sigint_handler);

    // Spawn a new shell
    printf("[+] Spawning a new shell in project directory. Type 'exit' to exit the shell.\n");

    pid_t pid = fork();
    if (pid == -1) {
        printf("\033[0;31m[!] Error forking process\033[0m\n");
        return;
    } else if (pid == 0) {
        // In child process, replace with the shell
        execlp("/bin/sh", "sh", NULL);
        // If execlp returns, there was an error
        printf("\033[0;31m[!] Error executing shell\033[0m\n");
        exit(1);
    } else {
        // In parent process, wait for the shell to exit
        int status;
        waitpid(pid, &status, 0);
    }

    // Restore default signal handling
    signal(SIGINT, SIG_DFL);
}

void open_code_file_in_editor(const char *project_name) {
    char code_file_path[512];
    char file_name[512];

    printf("[+] Enter the file name. Initial file name starts with \"start\" : ");
    fgets(file_name, sizeof(file_name), stdin);
    file_name[strcspn(file_name, "\n")] = '\0'; // Remove newline character

    snprintf(code_file_path, sizeof(code_file_path), "./projects/%s/%s", project_name, file_name);

    char command[1024];
    snprintf(command, sizeof(command), "sudo xdg-open \"%s\"", code_file_path);
    printf("[+] Running command: %s\n", command);
    int result = system(command);
    if (result == -1) {
        printf("\033[0;31m[!] Error executing command\033[0m\n");
    }
}

void open_backup() {
    char command[512];
    #ifdef _WIN32
        snprintf(command, sizeof(command), "explorer .\\backup");
    #else
        snprintf(command, sizeof(command), "xdg-open ./backup");
    #endif
    printf("[+] Running command: %s\n", command);
    int result = system(command);
    if (result == -1) {
        printf("\033[0;31m[!] Error executing command\033[0m\n");
    }
}

void open_explorer() {
    char command[512];
    #ifdef _WIN32
        snprintf(command, sizeof(command), "explorer ./projects/");
    #else
        snprintf(command, sizeof(command), "xdg-open ./projects");
    #endif
    printf("[+] Running command: %s\n", command);
    int result = system(command);
    if (result == -1) {
        printf("\033[0;31m[!] Error executing command\033[0m\n");
    }
}

void create_ascii_art() {
    char art_name[256];
    printf("[+] Enter the art name: ");
    fgets(art_name, sizeof(art_name), stdin);
    art_name[strcspn(art_name, "\n")] = '\0'; // Remove newline character

    // Ensure the arts directory exists
    struct stat st = {0};
    if (stat("./arts", &st) == -1) {
        mkdir("./arts", 0755);
    }

    printf("[+] Enter the ASCII art (type 'END' on a new line to finish):\n");

    char art_path[512];
    snprintf(art_path, sizeof(art_path), "./arts/%s.txt", art_name);
    FILE *art_file = fopen(art_path, "w");
    if (art_file == NULL) {
        printf("\033[0;31m[!] Error creating art file\033[0m\n");
        return;
    }

    char buffer[1024];
    while (1) {
        // Read input line by line
        if (fgets(buffer, sizeof(buffer), stdin) == NULL) {
            break; // Exit loop on EOF or read error
        }

        // Check for termination condition
        if (strcmp(buffer, "END\n") == 0) {
            break; // Stop reading input when "END" is encountered
        }

        // Write input to file
        fprintf(art_file, "%s", buffer);
    }

    fclose(art_file);
    printf("[+] ASCII art '%s' created successfully.\n", art_name);
}

char* get_project_mode(const char *project_name) {
    static char mode[256];
    char mode_file_path[512];
    snprintf(mode_file_path, sizeof(mode_file_path), "./projects/%s/mode.txt", project_name);

    FILE *mode_file = fopen(mode_file_path, "r");
    if (mode_file == NULL) {
        printf("\033[0;31m[!] Error reading mode file\033[0m\n");
        return NULL;
    }
    if (fgets(mode, sizeof(mode), mode_file) == NULL) {
        printf("\033[0;31m[!] Error reading mode\033[0m\n");
        fclose(mode_file);
        return NULL;
    }
    fclose(mode_file);

    // Remove trailing newline character
    mode[strcspn(mode, "\n")] = '\0';
    return mode;
}

int main() {
    while (1) {
        // List and sort projects first
        DIR *d;
        struct dirent *dir;
        d = opendir("./projects");
        if (!d) {
            printf("\033[0;31m[!] Could not open projects directory.\033[0m\n");
            return 1;
        }

        char *project_names[100];
        int project_count = 0;
        while ((dir = readdir(d)) != NULL) {
            if (dir->d_type == DT_DIR) {
                if (strcmp(dir->d_name, ".") != 0 && strcmp(dir->d_name, "..") != 0) {
                    project_names[project_count] = strdup(dir->d_name);
                    project_count++;
                }
            }
        }
        closedir(d);

        if (project_count == 0) {
            printf("No projects available. Let's get started together!\n");
        } else {
            qsort(project_names, project_count, sizeof(char *), compare);
        }

        // Print project list
        clear_screen2();
        printf("Silver, C-based game engine\n\n");
        printf("%s", get_random_meme());
        if (project_count > 0) {
            printf("[Available Projects]\n");
            for (int i = 0; i < project_count; i++) {
                printf("%d. %s\n", i + 1, project_names[i]);
            }
        }

        printf("\nEnter the project number to open or 'C' to create a new project: ");
        char input[256];
        fgets(input, sizeof(input), stdin);
        input[strcspn(input, "\n")] = '\0';

        if (input[0] == 'C' || input[0] == 'c') {
            char project_name[512];
            char mode[256];

            printf("Enter the new project name: ");
            fgets(project_name, sizeof(project_name), stdin);
            project_name[strcspn(project_name, "\n")] = '\0';

            do {
                printf("Select mode:\n");
                printf("{1} C\n");
                printf("{2} C-800 [Challenge]\n");
                printf("{3} TorchScript\n");
                printf("{4} Python [BETA]\n");
                printf("{5} Ruby [BETA]\n");
                printf("{6} Rust [BETA]\n");
                printf("{7} C++\n");
                printf("> ");
                fgets(mode, sizeof(mode), stdin);
                mode[strcspn(mode, "\n")] = '\0';

                if (strcmp(mode, "1") == 0 || strcmp(mode, "2") == 0 || strcmp(mode, "3")==0 || strcmp(mode,"4")== 0 || strcmp(mode,"5")==0 || strcmp(mode,"6")==0 || strcmp(mode,"7")==0) {
                    create_project(project_name, mode);
                    break; // Exit loop if a valid mode is selected
                } else {
                    printf("\033[0;31m[!] Invalid mode selected. Please try again.\033[0m\n");
                }
            } while (1); // Continue until a valid mode is entered
        } else {
            // Handle existing projects
            int project_number = atoi(input);
            if (project_number < 1 || project_number > project_count) {
                printf("\033[0;31m[!] Invalid project number.\033[0m\n");
                sleep(2);
                continue;
            }

            char selected_project[256];
            strncpy(selected_project, project_names[project_number - 1], sizeof(selected_project) - 1);

            clear_screen2();
            printf("Selected project: %s\n", selected_project);

            // Get the mode for the selected project
            const char *mode = get_project_mode(selected_project);
            if (mode == NULL) {
                printf("\033[0;31m[!] Could not retrieve project mode.\033[0m\n");
                sleep(2);
                continue;
            }

            while (1) {
                    printf("\nEnter command\n[1] Code\n[2] Execute\n[3] Open Backup\n[4] Archive Project\n[5] Create Ascii Art\n[6] Open Explorer\n[7] Command Line\n[8] Clean Up Project\n[9] Exit\n>  ");
		    fgets(input, sizeof(input), stdin);
		    input[strcspn(input, "\n")] = '\0';

		    if (strcmp(input, "1") == 0) {
			clear_screen2();
			open_code_file_in_editor(selected_project);
		    } else if (strcmp(input, "2") == 0) {
			clear_screen2();
			char *mode = get_project_mode(selected_project);
			execute_script(selected_project, mode);
		    } else if (strcmp(input, "3") == 0) {
			clear_screen2();
			open_backup();
		    } else if (strcmp(input, "4") == 0) {
			clear_screen2();
			archive_project(selected_project);
		    } else if (strcmp(input, "5") == 0) {
			clear_screen2();
			create_ascii_art();
		    } else if (strcmp(input, "6") == 0) {
			clear_screen2();
			open_explorer();
		    } else if (strcmp(input, "7") == 0) {
			get_command(selected_project);
		    } else if (strcmp(input, "8") == 0) {
			clear_screen2();
			cleanup_project(selected_project);
		    } else if (strcmp(input, "9") == 0) {
			clear_screen2();
			break;
		    } else {
			clear_screen2();
			printf("\n\033[0;31m[!] Invalid command. Try again.\033[0m\n");
		    }
		}
	}

		// Free allocated memory
	for (int i = 0; i < project_count; i++) {
		free(project_names[i]);
	}
}

    return 0;
}
